package utils

import (
	"time"

	"github.com/golang-jwt/jwt/v4"
)

type JWTutil struct {
	secret string
}

func NewJWTutils(secret string) *JWTutil {

	return &JWTutil{
		secret: secret,
	}
}

type CustomClaims struct {
	Username string `json:"username"`
	jwt.RegisteredClaims
}

// ============ 生成token ===========

func (j *JWTutil) GenerateToken(username string, expireSeconds int64) (string, error) {
	now := time.Now()
	expireTime := now.Add(time.Duration(expireSeconds) * time.Second)

	claims := &CustomClaims{
		Username: username,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(expireTime), // 5分钟后过期
			IssuedAt:  jwt.NewNumericDate(now),
			NotBefore: jwt.NewNumericDate(now),
			Issuer:    "vpn_api",
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(j.secret))
}

// ============ 验证 token是否失效 ============

func (j *JWTutil) Verifytoken(tokenString string) (*CustomClaims, error) {

	token, err := jwt.ParseWithClaims(
		tokenString, &CustomClaims{}, func(token *jwt.Token) (interface{}, error) {
			return []byte(j.secret), nil
		})

	if err != nil {
		return nil, err
	}
	if claims, ok := token.Claims.(*CustomClaims); ok && token.Valid {
		return claims, nil
	}

	return nil, jwt.ErrInvalidKey
}
