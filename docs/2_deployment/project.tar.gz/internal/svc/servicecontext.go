package svc

import (
	"project_vpn/internal/config"
	"project_vpn/internal/utils"
)

type ServiceContext struct {
	Config  config.Config
	JWTUtil *utils.JWTutil
}

func NewServiceContext(c config.Config) *ServiceContext {
	return &ServiceContext{
		Config:  c,
		JWTUtil: utils.NewJWTutils(c.JWTAuth.AccessSecret),
	}
}
