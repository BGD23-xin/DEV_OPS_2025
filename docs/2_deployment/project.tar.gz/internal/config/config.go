package config

import "github.com/zeromicro/go-zero/rest"

type Config struct {
	rest.RestConf
	UserConfigPath string `json:"UserConfigPath" default:"etc/users.json"`
	JWTAuth        JWTAuth
	ServerConfig   ServerConfig
}

type JWTAuth struct {
	AccessSecret string
	AccessExpire int64
}

type ServerConfig struct {
	Capass string
}
