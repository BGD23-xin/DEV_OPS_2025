package login

import (
	"net/http"

	"github.com/zeromicro/go-zero/rest/httpx"
	"project_vpn/internal/logic/login"
	"project_vpn/internal/svc"
	"project_vpn/internal/types"
)

func Delete_userHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req types.DeleteReq
		if err := httpx.Parse(r, &req); err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
			return
		}

		l := login.NewDelete_userLogic(r.Context(), svcCtx)
		resp, err := l.Delete_user(&req)
		if err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
		} else {
			httpx.OkJsonCtx(r.Context(), w, resp)
		}
	}
}
