package login

import (
	"net/http"

	"github.com/zeromicro/go-zero/rest/httpx"
	"project_vpn/internal/logic/login"
	"project_vpn/internal/svc"
)

func Get_infoHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		l := login.NewGet_infoLogic(r.Context(), svcCtx)
		resp, err := l.Get_info()
		if err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
		} else {
			httpx.OkJsonCtx(r.Context(), w, resp)
		}
	}
}
