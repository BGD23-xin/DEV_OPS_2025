package vpn_func

import (
	"fmt"
	"os/exec"
	"strings"
	"time"
)

// 查看
func List_of_user() (string, error) {
	cmdstr := `ls /etc/openvpn/pki/issued | awk -F'.' 'NF!=5' | sed 's/\.crt//'`

	cmd := exec.Command(
		"docker", "exec",
		"openvpn", "sh", "-c", cmdstr,
	)

	out, err := cmd.CombinedOutput()

	return string(out), err
}

// 读取 username 对应的	路由地址
func Read_ccd(username string) ([]string, error) {
	cmdstr := fmt.Sprintf(`cat /etc/openvpn/ccd/%v`, username)

	cmd := exec.Command(
		"docker", "exec",
		"openvpn", "sh", "-c", cmdstr,
	)

	out, err := cmd.CombinedOutput()

	lines := strings.Split(string(out), "\n")

	var ips []string

	for _, line := range lines {

		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		prefix := `push "route `
		if strings.HasPrefix(line, prefix) && strings.HasSuffix(line, `"`) {
			inner := strings.TrimPrefix(line, prefix)
			inner = strings.TrimSuffix(inner, `"`)
			ips = append(ips, inner)
		} else {
			// 否则直接 append
			ips = append(ips, line)
		}
	}
	return ips, err

}

// 读取 routes.conf 的 路由地址

func Read_routes() (map[string]string, error) {
	cmdstr := `cat /etc/openvpn/routes.conf`
	cmd := exec.Command(
		"docker", "exec",
		"openvpn", "sh", "-c", cmdstr,
	)

	data, err := cmd.CombinedOutput()

	// 转换成字典
	routes := map[string]string{}
	lines := strings.Split(string(data), "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		// 分成 key=value
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		name := parts[0]
		subnet := parts[1]
		routes[name] = subnet
	}

	return routes, err
}

func MapKeys(m map[string]string) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	return keys
}

// 计算有效期
func Days_of_expiration(username string) (*int, error) {
	inner_cmd := fmt.Sprintf("/etc/openvpn/pki/issued/%v.crt", username)
	cmd := exec.Command(
		"docker", "exec", "openvpn",
		"openssl", "x509",
		"-in", inner_cmd,
		"-noout", "-dates",
	)

	out, err := cmd.CombinedOutput()
	if err != nil {
		return nil, fmt.Errorf("openssl failed: %w, output: %s", err, out)
	}

	text := strings.TrimSpace(string(out))

	// ---- 正确解析 notAfter ----
	var notAfterStr string
	for _, line := range strings.Split(text, "\n") {
		if strings.HasPrefix(line, "notAfter=") {
			notAfterStr = strings.TrimPrefix(line, "notAfter=")
			break
		}
	}

	if notAfterStr == "" {
		return nil, fmt.Errorf("notAfter not found in output: %s", text)
	}

	// ---- 解析成时间 ----
	layout := "Jan 2 15:04:05 2006 MST"
	t, err := time.Parse(layout, notAfterStr)
	if err != nil {
		return nil, fmt.Errorf("parse time failed: %w", err)
	}

	// ---- 计算剩余天数 ----
	now := time.Now().UTC()
	remaining := int(t.Sub(now).Hours() / 24)

	return &remaining, nil
}

// 创建用户
func Create_user(Username, caPass string) (string, error) {

	cmdstr := fmt.Sprintf("easyrsa build-client-full %v nopass", Username)

	cmd := exec.Command(
		"docker", "compose", "run", "--rm",
		"-e", "EASYRSA_BATCH=1",
		"-e", "EASYRSA_PASSIN=pass:"+caPass,
		"openvpn", "sh", "-c",
		cmdstr,
	)
	out, err := cmd.CombinedOutput()

	return string(out), err

}

// 创建同时 配置 路由文件
func Write_routes(username string, keys []string, dict map[string]string) error {
	var selected []string
	if len(keys) == 0 {
		for name := range dict {
			selected = append(selected, name)
		}
	} else {
		selected = keys
	}

	var lines []string
	for _, name := range selected {
		subnet, ok := dict[name]

		if !ok {
			continue // key 不存在就跳过
		}
		line := fmt.Sprintf(`push "route %s"`, subnet)
		lines = append(lines, line)
	}

	content := ""
	if len(lines) > 0 {
		content = strings.Join(lines, "\n") + "\n"
	}

	cmd := exec.Command(
		"docker", "exec", "-i",
		"openvpn",
		"sh", "-c",
		fmt.Sprintf("mkdir -p /etc/openvpn/ccd && cat > /etc/openvpn/ccd/%s", username),
	)
	cmd.Stdin = strings.NewReader(content)

	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("write CCD failed: %w, output: %s", err, out)
	}

	return err
}

// 删除用户
func Delete_user(Username, caPass string) (string, error) {
	// 1.删除用户

	baseCom := []string{
		"compose", "run", "--rm",
		"-e", "EASYRSA_BATCH=1",
		"-e", "EASYRSA_PASSIN=pass:" + caPass,
		"openvpn",
	}

	revoke := append(baseCom, "easyrsa", "revoke", Username)

	out_revo, err_revo := exec.Command("docker", revoke...).CombinedOutput()

	if err_revo != nil {
		return string(out_revo), fmt.Errorf("revoke failed: %w, output: %s", err_revo, out_revo)
	}

	// 2.更新 crl
	gen_args := append(baseCom, "easyrsa", "gen-crl")

	out_gen, err_gen := exec.Command("docker", gen_args...).CombinedOutput()

	if err_gen != nil {
		return string(out_gen), fmt.Errorf("revoke failed: %w, output: %s", err_gen, out_gen)
	}

	// 生成新的crl

	cp_args := append(baseCom, "sh", "-c", "cp -f /etc/openvpn/pki/crl.pem crl.pem")

	out_cp, err_cp := exec.Command("docker", cp_args...).CombinedOutput()

	if err_cp != nil {
		return string(out_cp), fmt.Errorf("cp crl failed: %w, output: %s", err_cp, out_cp)
	}

	// 删除 对应的ccd文件
	cmdstr := fmt.Sprintf(`rm /etc/openvpn/ccd/%v`, Username)
	cmd_2 := exec.Command(
		"docker", "exec",
		"openvpn", "sh", "-c", cmdstr,
	)
	out, err := cmd_2.CombinedOutput()

	if err != nil {
		return string(out), fmt.Errorf("cp crl failed: %w, output: %s", err, out)
	}
	// // 删除对应的 .ovpn 文件
	// saveDir := "user"
	// filename := filepath.Join(saveDir, Username+".ovpn")
	// if err := os.Remove(filename); err != nil && !os.IsNotExist(err) {
	// 	return "", fmt.Errorf("remove local config failed: %w", err)
	// }

	return "用户删除成功", nil

}

// 将用户在吊销之后踢下线
func Kick_off(username string) (string, error) {

	innerCmd := fmt.Sprintf(
		`printf "kill %s\r\nquit\r\n" | nc 127.0.0.1 7505`,
		username,
	)

	cmd := exec.Command(
		"docker", "exec", "openvpn",
		"sh", "-lc", innerCmd,
	)

	out, err := cmd.CombinedOutput()
	if err != nil {
		return string(out), fmt.Errorf("kickOff failed: %w, output: %s", err, out)
	}

	return string(out), nil
}

// 生成 .ovpn 文件
func Generate_file(username string) (string, error) {

	cmd := exec.Command(
		"docker", "exec",
		"openvpn", "ovpn_getclient", username,
	)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return string(out), fmt.Errorf("kickOff failed: %w, output: %s", err, out)
	}

	raw := string(out)

	// 删除 "redirect-gateway"
	lines := []string{}

	for _, line := range strings.Split(raw, "\n") {
		if strings.HasPrefix(strings.TrimSpace(line), "redirect-gateway") {
			continue // 跳过
		}
		lines = append(lines, line)
	}

	// 添加 安全选项

	extraLines := []string{
		"cipher AES-256-CBC",
		"data-ciphers AES-256-CBC",
		"data-ciphers-fallback AES-256-CBC",
		"resolv-retry infinite",
	}

	finalContent := strings.Join(append(lines, extraLines...), "\n") + "\n"

	// // 写入文件
	// saveDir := "user"
	// if err := os.MkdirAll(saveDir, 0755); err != nil {
	// 	return "", fmt.Errorf("create dir failed: %w", err)
	// }

	// // 完整路径
	// filename := fmt.Sprintf("%s/%s.ovpn", saveDir, username)

	// // 写文件
	// if err := os.WriteFile(filename, []byte(finalContent), 0644); err != nil {
	// 	return "", fmt.Errorf("write ovpn file failed: %w", err)
	// }

	return finalContent, nil
}
