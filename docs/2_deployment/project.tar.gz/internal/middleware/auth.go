package middleware

import (
	"context"
	"net/http"
	"project_vpn/internal/svc"
	"strings"
)

type AuthMiddleware struct {
	svcCtx *svc.ServiceContext
}

func NewAuthMiddleware(svcCtx *svc.ServiceContext) *AuthMiddleware {
	return &AuthMiddleware{
		svcCtx: svcCtx,
	}
}

func (m *AuthMiddleware) Handle(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		token := r.Header.Get("Authorization")

		if token == "" {
			w.WriteHeader(http.StatusUnauthorized)
			w.Write([]byte(`{"code": 401, "message": "未提供token"}`))
			return
		}

		// 	去掉前缀 bearer
		token = strings.TrimPrefix(token, "Bearer ")

		// 	校验 token

		claims, err := m.svcCtx.JWTUtil.Verifytoken(token)

		if err != nil {
			w.WriteHeader(http.StatusUnauthorized)
			w.Write([]byte(`{"code": 401, "message": "token无效或已过期"}`))
			return
		}

		ctx := context.WithValue(r.Context(), "username", claims.Username)

		newReq := r.WithContext(ctx)

		next(w, newReq)

	}

}
