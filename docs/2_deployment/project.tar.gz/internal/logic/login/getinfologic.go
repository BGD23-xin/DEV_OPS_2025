package login

import (
	"context"
	"fmt"

	"project_vpn/internal/svc"
	"project_vpn/internal/types"
	"project_vpn/internal/vpn_func"

	"github.com/zeromicro/go-zero/core/logx"

	"strings"
)

type Get_infoLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewGet_infoLogic(ctx context.Context, svcCtx *svc.ServiceContext) *Get_infoLogic {
	return &Get_infoLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

// 更改输出格式
func (l *Get_infoLogic) processUserList(cmdOutput string) []types.UserInfo {
	// 按行分割输出
	lines := strings.Split(strings.TrimSpace(cmdOutput), "\n")

	var users []types.UserInfo

	for _, line := range lines {
		username := strings.TrimSpace(line)
		if username == "" {
			continue
		}

		ips, err := vpn_func.Read_ccd(username)

		if err != nil {
			fmt.Print(err)
		}

		// 为每个用户创建 UserInfo，selected_routes 可以先为空
		map_routes, err := vpn_func.Read_routes()
		if err != nil {
			return nil
		}

		var routes []string

		for _, ip := range ips {
			for key := range map_routes {
				if ip == map_routes[key] {
					routes = append(routes, key)
				}
			}
		}

		days, err := vpn_func.Days_of_expiration(username)
		if err != nil {
			return nil
		}
		if len(routes) == len(map_routes) {
			routes = []string{"全路由"}
		}
		user := types.UserInfo{
			Username:       username,
			SelectedRoutes: routes, // 这里可以根据需要从其他地方获取路由信息
			Expiration:     fmt.Sprintf("%d", *days),
		}
		users = append(users, user)
	}

	return users
}

func (l *Get_infoLogic) Get_info() (resp *types.GetInfoResp, err error) {

	// 调用 vpn_func 包中的函数获取用户列表
	data, err := vpn_func.List_of_user()
	if err != nil {
		return &types.GetInfoResp{
			Code:    "500",
			Message: "获取VPN用户列表失败: " + err.Error(),
		}, nil
	}

	// 处理命令输出，转换为用户列表
	users := l.processUserList(data)

	return &types.GetInfoResp{
		Code:    "200",
		Message: "获取成功",
		Users:   users,
	}, nil
}
