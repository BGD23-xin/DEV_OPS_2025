package login

import (
	"context"

	"github.com/zeromicro/go-zero/core/logx"
	"project_vpn/internal/svc"
	"project_vpn/internal/types"
	"project_vpn/internal/vpn_func"
)

type Create_userLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewCreate_userLogic(ctx context.Context, svcCtx *svc.ServiceContext) *Create_userLogic {
	return &Create_userLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *Create_userLogic) Create_user(req *types.Create_userReq) (resp *types.Create_userResp, err error) {
	// todo: add your logic here and delete this line

	//创建账户
	data, err := vpn_func.Create_user(req.Username, l.svcCtx.Config.ServerConfig.Capass)

	if err != nil {
		return &types.Create_userResp{
			Message: "无法创建: " + err.Error(),
		}, nil
	}

	map_routes, err := vpn_func.Read_routes()
	if err != nil {
		return nil, err
	}
	if string(data) != "" {

		err := vpn_func.Write_routes(req.Username, req.Selected_routes, map_routes)

		if err != nil {
			return &types.Create_userResp{
				Message: "无法创建: " + err.Error(),
			}, nil
		}

	}
	return &types.Create_userResp{
		Message: "创建成功",
	}, nil
}
