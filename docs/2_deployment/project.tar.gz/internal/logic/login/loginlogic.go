package login

import (
	"context"
	"encoding/json"
	"os"
	"project_vpn/internal/svc"
	"project_vpn/internal/types"

	"github.com/golang-jwt/jwt/v4"
	"github.com/zeromicro/go-zero/core/logx"
)

type LoginLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

type CustomClaims struct {
	Username string `json:"username"`
	jwt.RegisteredClaims
}

func NewLoginLogic(ctx context.Context, svcCtx *svc.ServiceContext) *LoginLogic {
	return &LoginLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

// ============ 加载文件 ==============
func (l *LoginLogic) loaduserfile() ([]types.AdminUser, error) {

	filepath := l.svcCtx.Config.UserConfigPath

	file, err := os.Open(filepath)

	if err != nil {
		return nil, err
	}

	defer file.Close()

	var users []types.AdminUser

	decoder := json.NewDecoder(file)

	if err := decoder.Decode(&users); err != nil {
		return nil, err
	}
	return users, nil
}

// ============ 验证 用户名和密码 ===========
func (l *LoginLogic) validateUser(users []types.AdminUser, username, password string) bool {

	for _, user := range users {
		if user.Username == username && user.Password == password {
			return true
		}

	}
	return false
}

// =============== 登陆 ==================
func (l *LoginLogic) Login(req *types.LoginReq) (resp *types.LoginResp, err error) {
	// todo: add your logic here and delete this line

	users, err := l.loaduserfile()

	if err != nil {
		return nil, err
	}

	if !l.validateUser(users, req.Username, req.Password) {
		return &types.LoginResp{
			Code:    "500",
			Message: "wrong",
		}, nil
	}
	token, err := l.svcCtx.JWTUtil.GenerateToken(req.Username, l.svcCtx.Config.JWTAuth.AccessExpire)
	if err != nil {
		return &types.LoginResp{
			Code:    "500",
			Message: "系统错误：生成token失败",
		}, nil
	}

	return &types.LoginResp{
		Code:    "200",
		Message: "登录成功",
		Token:   token,
	}, nil
}
