package login

import (
	"context"
	"fmt"

	"project_vpn/internal/svc"
	"project_vpn/internal/types"

	"github.com/zeromicro/go-zero/core/logx"

	"project_vpn/internal/vpn_func"
)

type Delete_userLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewDelete_userLogic(ctx context.Context, svcCtx *svc.ServiceContext) *Delete_userLogic {
	return &Delete_userLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *Delete_userLogic) Delete_user(req *types.DeleteReq) (resp *types.DeleteResp, err error) {
	// todo: add your logic here and delete this line

	data, err := vpn_func.Delete_user(req.Username, l.svcCtx.Config.ServerConfig.Capass)

	if err != nil {
		return &types.DeleteResp{
			Message: "无法删除: " + err.Error(),
		}, nil
	}

	if string(data) != "" {

		_, err := vpn_func.Kick_off(req.Username)

		if err != nil {
			return &types.DeleteResp{
				Message: "无法创建: " + err.Error(),
			}, nil
		}

	}
	return &types.DeleteResp{
		Message: fmt.Sprintf("成功删除%v", req.Username),
	}, nil
}
