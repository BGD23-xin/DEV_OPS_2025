package login

import (
	"context"

	"project_vpn/internal/svc"
	"project_vpn/internal/types"

	"encoding/base64"
	"project_vpn/internal/vpn_func"

	"github.com/zeromicro/go-zero/core/logx"
)

type DownloadLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewDownloadLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DownloadLogic {
	return &DownloadLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *DownloadLogic) Download(req *types.DownloadReq) (resp *types.DownloadResp, err error) {
	// todo: add your logic here and delete this line
	content, err := vpn_func.Generate_file(req.Username)

	if err != nil {
		return &types.DownloadResp{
			Message: "无法下载: " + err.Error(),
		}, nil
	}

	contentBytes := []byte(content)
	return &types.DownloadResp{
		FileName: req.Username + ".ovpn",
		Content:  base64.StdEncoding.EncodeToString(contentBytes),
		Message:  "success",
	}, nil
}
