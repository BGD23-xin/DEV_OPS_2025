package config

import "github.com/zeromicro/go-zero/rest"

type Adminconfig struct {
	Username string
	Password string
}

type Config struct {
	rest.RestConf
	Admin Adminconfig
}
