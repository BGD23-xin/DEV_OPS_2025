package logic

import (
	"context"

	"vpn_api/internal/svc"
	"vpn_api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type DownloadUserLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewDownloadUserLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DownloadUserLogic {
	return &DownloadUserLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *DownloadUserLogic) DownloadUser(req *types.DownloadReq) (resp *types.DownloadResp, err error) {
	// todo: add your logic here and delete this line

	return
}
