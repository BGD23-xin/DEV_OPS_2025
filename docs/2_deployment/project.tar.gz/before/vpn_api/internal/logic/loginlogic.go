package logic

import (
	"context"

	"vpn_api/internal/svc"
	"vpn_api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/x/errors"
)

type LoginLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewLoginLogic(ctx context.Context, svcCtx *svc.ServiceContext) *LoginLogic {
	return &LoginLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *LoginLogic) Login(req *types.LoginReq) (resp *types.LoginResp, err error) {
	// todo: add your logic here and delete this line
	cfg := l.svcCtx.Config

	if req.Username != cfg.Admin.Username || req.Password != cfg.Admin.Password {
		return nil, errors.New(401, "invalid username or password")

	}
	return &types.LoginResp{Token: "dumy token"}, nil
}
