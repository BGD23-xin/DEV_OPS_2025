package main

import (
	"fmt"
	"os"
	"os/exec"
	"strings"
	"time"
)

// 查看
func list_of_user() (string, error) {
	cmdstr := `ls /etc/openvpn/pki/issued | awk -F'.' 'NF!=5' | sed 's/\.crt//'`

	cmd := exec.Command(
		"docker", "exec",
		"openvpn", "sh", "-c", cmdstr,
	)

	out, err := cmd.CombinedOutput()
	return string(out), err
}

// 创建
func create_user(Username, caPass string) (string, error) {

	cmdstr := fmt.Sprintf("easyrsa build-client-full %v nopass", Username)

	cmd := exec.Command(
		"docker", "compose", "run", "--rm",
		"-e", "EASYRSA_CERT_EXPIRE=180",
		"-e", "EASYRSA_BATCH=1",
		"-e", "EASYRSA_PASSIN=pass:"+caPass,
		"openvpn", "sh", "-c",
		cmdstr,
	)
	out, err := cmd.CombinedOutput()

	return string(out), err

}

// 创建局部路由文件

func read_routes() (map[string]string, error) {
	cmdstr := `cat /etc/openvpn/routes.conf`
	cmd := exec.Command(
		"docker", "exec",
		"openvpn", "sh", "-c", cmdstr,
	)

	data, err := cmd.CombinedOutput()

	// 转换成字典
	routes := map[string]string{}
	lines := strings.Split(string(data), "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		// 分成 key=value
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		name := parts[0]
		subnet := parts[1]
		routes[name] = subnet
	}

	return routes, err
}

func mapKeys(m map[string]string) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	return keys
}

func write_routes(username string, keys []string, dict map[string]string) error {
	var selected []string
	if len(keys) == 0 {
		for name := range dict {
			selected = append(selected, name)
		}
	} else {
		selected = keys
	}

	var lines []string
	for _, name := range selected {
		subnet, ok := dict[name]

		if !ok {
			continue // key 不存在就跳过
		}
		line := fmt.Sprintf(`push "route %s"`, subnet)
		lines = append(lines, line)
	}

	content := ""
	if len(lines) > 0 {
		content = strings.Join(lines, "\n") + "\n"
	}

	cmd := exec.Command(
		"docker", "exec", "-i",
		"openvpn",
		"sh", "-c",
		fmt.Sprintf("mkdir -p /etc/openvpn/ccd && cat > /etc/openvpn/ccd/%s", username),
	)
	cmd.Stdin = strings.NewReader(content)

	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("write CCD failed: %w, output: %s", err, out)
	}

	return err
}

func errors(err error) {
	if err != nil {

		fmt.Print("the command is not right", err)
	}
}

// 删除 用户
func delete_user(Username, caPass string) (string, error) {
	// 1.删除用户

	baseCom := []string{
		"compose", "run", "--rm",
		"-e", "EASYRSA_BATCH=1",
		"-e", "EASYRSA_PASSIN=pass:" + caPass,
		"openvpn",
	}

	revoke := append(baseCom, "easyrsa", "revoke", Username)

	out_revo, err_revo := exec.Command("docker", revoke...).CombinedOutput()

	if err_revo != nil {
		return string(out_revo), fmt.Errorf("revoke failed: %w, output: %s", err_revo, out_revo)
	}

	// 2.更新 crl
	gen_args := append(baseCom, "easyrsa", "gen-crl")

	out_gen, err_gen := exec.Command("docker", gen_args...).CombinedOutput()

	if err_gen != nil {
		return string(out_gen), fmt.Errorf("revoke failed: %w, output: %s", err_gen, out_gen)
	}

	// 生成新的crl

	cp_args := append(baseCom, "sh", "-c", "cp -f /etc/openvpn/pki/crl.pem crl.pem")

	out_cp, err_cp := exec.Command("docker", cp_args...).CombinedOutput()

	if err_cp != nil {
		return string(out_cp), fmt.Errorf("cp crl failed: %w, output: %s", err_cp, out_cp)
	}

	return string(out_cp), nil

}

// 剔用户下线

func kick_off(username string) (string, error) {

	innerCmd := fmt.Sprintf(
		`printf "kill %s\r\nquit\r\n" | nc 127.0.0.1 7505`,
		username,
	)

	cmd := exec.Command(
		"docker", "exec", "openvpn",
		"sh", "-lc", innerCmd,
	)

	out, err := cmd.CombinedOutput()
	if err != nil {
		return string(out), fmt.Errorf("kickOff failed: %w, output: %s", err, out)
	}

	return string(out), nil
}

func generate_file(username string) (string, error) {

	cmd := exec.Command(
		"docker", "exec",
		"openvpn", "ovpn_getclient", username,
	)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return string(out), fmt.Errorf("kickOff failed: %w, output: %s", err, out)
	}

	raw := string(out)

	// 删除 "redirect-gateway"
	lines := []string{}

	for _, line := range strings.Split(raw, "\n") {
		if strings.HasPrefix(strings.TrimSpace(line), "redirect-gateway") {
			continue // 跳过
		}
		lines = append(lines, line)
	}

	// 添加 安全选项

	extraLines := []string{
		"cipher AES-256-CBC",
		"data-ciphers AES-256-CBC",
		"data-ciphers-fallback AES-256-CBC",
		"resolv-retry infinite",
	}

	finalContent := strings.Join(append(lines, extraLines...), "\n") + "\n"

	// 写入文件

	filename := fmt.Sprintf("%s.ovpn", username)
	err = os.WriteFile(filename, []byte(finalContent), 0644)
	if err != nil {
		return "", fmt.Errorf("write ovpn file failed: %w", err)
	}

	return filename, nil
}

func days_of_expiration(username string) (*int, error) {
	inner_cmd := fmt.Sprintf("/etc/openvpn/pki/issued/%v.crt", username)
	cmd := exec.Command(
		"docker", "exec", "openvpn",
		"openssl", "x509",
		"-in", inner_cmd,
		"-noout", "-dates",
	)

	out, err := cmd.CombinedOutput()
	if err != nil {
		return nil, fmt.Errorf("openssl failed: %w, output: %s", err, out)
	}

	text := strings.TrimSpace(string(out))

	// ---- 正确解析 notAfter ----
	var notAfterStr string
	for _, line := range strings.Split(text, "\n") {
		if strings.HasPrefix(line, "notAfter=") {
			notAfterStr = strings.TrimPrefix(line, "notAfter=")
			break
		}
	}

	if notAfterStr == "" {
		return nil, fmt.Errorf("notAfter not found in output: %s", text)
	}

	// ---- 解析成时间 ----
	layout := "Jan 2 15:04:05 2006 MST"
	t, err := time.Parse(layout, notAfterStr)
	if err != nil {
		return nil, fmt.Errorf("parse time failed: %w", err)
	}

	// ---- 计算剩余天数 ----
	now := time.Now().UTC()
	remaining := int(t.Sub(now).Hours() / 24)

	return &remaining, nil
}

func Read_ccd(username string) ([]string, error) {
	cmdstr := fmt.Sprintf(`cat /etc/openvpn/ccd/%v`, username)

	cmd := exec.Command(
		"docker", "exec",
		"openvpn", "sh", "-c", cmdstr,
	)

	out, err := cmd.CombinedOutput()

	lines := strings.Split(string(out), "\n")

	var ips []string

	for _, line := range lines {

		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		prefix := `push "route `
		if strings.HasPrefix(line, prefix) && strings.HasSuffix(line, `"`) {
			inner := strings.TrimPrefix(line, prefix)
			inner = strings.TrimSuffix(inner, `"`)
			ips = append(ips, inner)
		} else {
			// 否则直接 append
			ips = append(ips, line)
		}
	}
	return ips, err

}

func main() {
	dict, _ := read_routes()
	// keys := mapKeys(dict)

	fmt.Print(dict)

	// errors(err)

	user := "xin"
	keys_1 := []string{"iot-cn-test-ms-cn-northwest-1a", "iot-cn-test-ms-cn-northwest-1b", "iot-cn-test-cluster-cn-northwest-1a", "iot-cn-test-cluster-cn-northwest-1b"}
	out_1 := write_routes(user, keys_1, dict)
	// out, err := Read_ccd(user)

	// errors(err)
	fmt.Print(out_1)
	// user := "li"
	// capass := "123456"

	// _, err_create := create_user(user, capass)

	// errors(err_create)

	// out_gene_date_1, _ := days_of_expiration(user)

	// fmt.Print(*out_gene_date_1)

	// out_list, err_list := list_of_user()

	// errors(err_list)

	// fmt.Print(out_list)

	// del_user := "li"

	// _, err_del := delete_user(del_user, capass)

	// errors(err_del)

	// out_list_kick, err_kick := kick_off(del_user)

	// errors(err_kick)
	// fmt.Print(out_list_kick)

	// user_2 := "xin"

	// out_gene_date, _ := days_of_expiration(user_2)

	// fmt.Print(*out_gene_date)
	// out_gene_doc, err_gene_doc := generate_file(user_2)

	// errors(err_gene_doc)
	// fmt.Print(out_gene_doc)
}
